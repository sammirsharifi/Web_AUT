import re
import requests


def url_validator(url):
    regex = re.compile(
        r'^(?:http|ftp)s?://'  
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  
        r'localhost|'  
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})' 
        r'(?::\d+)?'
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)

    return re.match(regex, url) is not None


url = input("Enter URL:")
method = input("Enter request method:")

if not url_validator(url):
    print("URL is invalid")
    exit()
if not method.lower() in ["get", "put", "post", "patch", "delete"]:
    print("method is invalid")
    exit()
response = requests.request(method=method, url=url)
content_type = response.headers.get("content-type").split(";")[0]
status = response.status_code

if str(status).startswith("2"):
    if content_type == "text/html":
        with open('./page.html', 'wb+') as f:
            f.write(response.content)
    elif content_type == "application/json":
        with open('./file.json', 'wb+') as f:
            f.write(response.content)
    else:
        print(response.content)
elif str(status).startswith("3"):
    print("Resource has been moved.")
elif str(status).startswith("4"):
    print("Client error ")
elif str(status).startswith("5"):
    print("Server error ")

